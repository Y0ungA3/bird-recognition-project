CUB-200-2011 鸟类细粒度识别项目
补充材料说明

提交文件：
  FINAL_REPORT.pdf       Final Report
  MILESTONE.pdf          Milestone
  SUPPLEMENTARY_MATERIAL.zip

补充材料 ZIP 包含：
  code/                  训练、评估、作图和复现脚本
  reports/               LaTeX 源文件与 PDF
  results/report_visuals 统一风格的报告图
  results/final_model    最终模型卡、Grad-CAM、混淆图
  results/final_test_analysis 唯一一次官方测试结果
  results/margin_ablation     鸟框扩展范围消融结果
  results/freeze_finetune_comparison 训练策略比较
  results/local_geometry_comparison  控制实验
  results/background_summary 背景干预文本与汇总数据

ZIP不包含：
  CUB原始数据
  训练checkpoint
  PyTorch/CUDA依赖
  虚拟环境
  下载缓存

最终模型：
  ResNet-18 ImageNet预训练
  CUB真实鸟框，margin 0%
  letterbox
  从第1轮全参数微调
  seed 43

官方测试集（5,794张）：
  Top-1 77.87%
  Top-5 94.15%
  Macro-F1 77.85%

模型在官方测试集评估前冻结，测试后没有重新选择或调整。

实现、实验编排和作图代码在Codex辅助下完成；
作者应自行核验代码、结果解释和课程AI使用政策。

